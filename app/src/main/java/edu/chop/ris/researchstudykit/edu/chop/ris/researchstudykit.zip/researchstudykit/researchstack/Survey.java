package edu.chop.ris.researchstudykit.edu.chop.ris.researchstudykit.researchstack;

import java.util.List;

/**
 * Created by danie on 10/26/2017.
 */

public class Survey {
    List<SurveyQuestion> questions;


}
