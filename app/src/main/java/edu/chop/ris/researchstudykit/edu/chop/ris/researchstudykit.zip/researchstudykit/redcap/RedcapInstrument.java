package edu.chop.ris.researchstudykit.edu.chop.ris.researchstudykit.redcap;

import java.util.List;

/**
 * Created by danie on 10/16/2017.
 */

public class RedcapInstrument {
    String name;
    List<RedcapQuestion> questions;

}
